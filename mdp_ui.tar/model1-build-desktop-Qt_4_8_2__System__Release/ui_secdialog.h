/********************************************************************************
** Form generated from reading UI file 'secdialog.ui'
**
** Created: Sun Jul 12 22:29:38 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECDIALOG_H
#define UI_SECDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_secDialog
{
public:
    QLabel *label;
    QPushButton *pushButton;

    void setupUi(QDialog *secDialog)
    {
        if (secDialog->objectName().isEmpty())
            secDialog->setObjectName(QString::fromUtf8("secDialog"));
        secDialog->resize(400, 300);
        label = new QLabel(secDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 60, 130, 30));
        pushButton = new QPushButton(secDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 180, 80, 25));

        retranslateUi(secDialog);

        QMetaObject::connectSlotsByName(secDialog);
    } // setupUi

    void retranslateUi(QDialog *secDialog)
    {
        secDialog->setWindowTitle(QApplication::translate("secDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("secDialog", "Please switch mode:", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("secDialog", "Done", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class secDialog: public Ui_secDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECDIALOG_H
