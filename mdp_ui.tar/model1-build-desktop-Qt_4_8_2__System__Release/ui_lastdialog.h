/********************************************************************************
** Form generated from reading UI file 'lastdialog.ui'
**
** Created: Sun Jul 12 23:17:00 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LASTDIALOG_H
#define UI_LASTDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_lastDialog
{
public:
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QLabel *label_3;
    QTableWidget *table;

    void setupUi(QDialog *lastDialog)
    {
        if (lastDialog->objectName().isEmpty())
            lastDialog->setObjectName(QString::fromUtf8("lastDialog"));
        lastDialog->resize(400, 300);
        label = new QLabel(lastDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(170, 40, 80, 30));
        label_2 = new QLabel(lastDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(60, 200, 170, 30));
        pushButton = new QPushButton(lastDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(260, 200, 80, 25));
        label_3 = new QLabel(lastDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 80, 91, 100));
        table = new QTableWidget(lastDialog);
        if (table->columnCount() < 2)
            table->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        table->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        table->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        if (table->rowCount() < 2)
            table->setRowCount(2);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        table->setVerticalHeaderItem(0, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        table->setVerticalHeaderItem(1, __qtablewidgetitem3);
        table->setObjectName(QString::fromUtf8("table"));
        table->setGeometry(QRect(50, 80, 311, 91));
        table->setBaseSize(QSize(50, 50));
        table->setAutoScroll(true);
        table->setAutoScrollMargin(16);
        table->setRowCount(2);
        table->setColumnCount(2);

        retranslateUi(lastDialog);

        QMetaObject::connectSlotsByName(lastDialog);
    } // setupUi

    void retranslateUi(QDialog *lastDialog)
    {
        lastDialog->setWindowTitle(QApplication::translate("lastDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("lastDialog", "Results:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("lastDialog", "Please remove handpiece.", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("lastDialog", "Exit", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("lastDialog", "Speed", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = table->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("lastDialog", "Value", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = table->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("lastDialog", "Status", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = table->verticalHeaderItem(0);
        ___qtablewidgetitem2->setText(QApplication::translate("lastDialog", "Speed(RPM)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = table->verticalHeaderItem(1);
        ___qtablewidgetitem3->setText(QApplication::translate("lastDialog", "Current(Amp)", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class lastDialog: public Ui_lastDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LASTDIALOG_H
