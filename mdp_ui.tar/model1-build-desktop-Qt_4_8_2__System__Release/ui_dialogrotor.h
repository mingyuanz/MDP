/********************************************************************************
** Form generated from reading UI file 'dialogrotor.ui'
**
** Created: Sun Jul 12 22:23:27 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGROTOR_H
#define UI_DIALOGROTOR_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QProgressBar>

QT_BEGIN_NAMESPACE

class Ui_DialogRotor
{
public:
    QLabel *label;
    QProgressBar *progressBar;

    void setupUi(QDialog *DialogRotor)
    {
        if (DialogRotor->objectName().isEmpty())
            DialogRotor->setObjectName(QString::fromUtf8("DialogRotor"));
        DialogRotor->resize(400, 300);
        label = new QLabel(DialogRotor);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(145, 30, 120, 30));
        progressBar = new QProgressBar(DialogRotor);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(130, 140, 140, 25));
        progressBar->setValue(0);

        retranslateUi(DialogRotor);

        QMetaObject::connectSlotsByName(DialogRotor);
    } // setupUi

    void retranslateUi(QDialog *DialogRotor)
    {
        DialogRotor->setWindowTitle(QApplication::translate("DialogRotor", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogRotor", "Testing on Rotor...", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogRotor: public Ui_DialogRotor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGROTOR_H
