/********************************************************************************
** Form generated from reading UI file 'thirddialog.ui'
**
** Created: Sun Jul 12 02:20:24 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_THIRDDIALOG_H
#define UI_THIRDDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QProgressBar>

QT_BEGIN_NAMESPACE

class Ui_thirdDialog
{
public:
    QLabel *label;
    QProgressBar *progressBar;

    void setupUi(QDialog *thirdDialog)
    {
        if (thirdDialog->objectName().isEmpty())
            thirdDialog->setObjectName(QString::fromUtf8("thirdDialog"));
        thirdDialog->resize(400, 300);
        label = new QLabel(thirdDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(140, 40, 131, 31));
        progressBar = new QProgressBar(thirdDialog);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(140, 140, 131, 23));
        progressBar->setValue(0);

        retranslateUi(thirdDialog);

        QMetaObject::connectSlotsByName(thirdDialog);
    } // setupUi

    void retranslateUi(QDialog *thirdDialog)
    {
        thirdDialog->setWindowTitle(QApplication::translate("thirdDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("thirdDialog", "Continuing Test...", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class thirdDialog: public Ui_thirdDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_THIRDDIALOG_H
